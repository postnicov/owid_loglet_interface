clear;close all;clc;
FS=20;%Font size for figures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Printing options
printfigures=1;% 1 - "print"; 0 - "do not print";
frmt='-dpdf';
res=300;%resolution in dpi
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load Spain

[lent,cols]=size(datosprovincias);
P=52;%numbr of provinces
days=lent/P;

for j=1:days;
    I(j)=sum(cell2mat(datosprovincias(52*(j-1)+1:52*j,3)));
end

ind = strfind(datosprovincias(:,1),'CA');
ind=find(~cellfun(@isempty,ind));

ICA=cell2mat(datosprovincias(ind,3));

ind = strfind(datosprovincias(:,1),'MA');
ind=find(~cellfun(@isempty,ind));

IMA=cell2mat(datosprovincias(ind,3));

date=datosprovincias(1:52:end,2);
t=0:days-1;

subplot(2,1,1)
plot(t,ICA,'-','LineWidth',1.5);
hold on
plot(t,IMA,'LineWidth',1.5);
l1=legend({'Catalonia','Madrid'});
set(l1,'FontSize',FS)
xlim([0 121])
ylabel('Cases per day')
set(gca,'XTick',[t(32):35:t(140)],'XTickLabel',[date(32:35:140)],'FontSize',FS)
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 10 6],'PaperSize',[10 6])

subplot(2,1,2)
plot(cumsum(ICA),'-','LineWidth',1.5)
hold on
plot(cumsum(IMA),'LineWidth',1.5)
l1=legend({'Catalonia','Madrid'});
set(l1,'FontSize',FS)
xlim([0 121])
ylabel('Cumulative number')
set(gca,'XTick',[t(32):35:t(140)],'XTickLabel',[date(32:35:140)],'FontSize',FS)
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 10 6],'PaperSize',[10 6])

%print('regES',frmt,['-r',num2str(res)]) 

A=['Days since ',date{1}];
total_cases=cumsum(IMA+ICA);
u=[t(1:121)',total_cases(1:121)];
textHeader = cell2mat({A,',Total cases'});
outfilename=['Two_regions_of_Spain.csv'];
fid = fopen(outfilename,'w'); 
fprintf(fid,'%s\n',textHeader);
fclose(fid);
dlmwrite(outfilename,u,'-append');


%%%%
fid = fopen('processed_file_info.txt','w'); 
fprintf(fid,'%s\r\n',outfilename);
fprintf(fid,'%s\r\n','SpainRegions');
for j=1:121;
    fprintf(fid,'%10s\r\n',char(date(j)));
end
fclose(fid);



% %% For LogletLab
% 
% Tout(1:121,1)=t(1:121);
% Tout(1:121,2)=cumsum(ICA(1:121))+cumsum(IMA(1:121));
% 
% %% Read info and Loglet Lab and files
% fid = fopen('processed_file_info.txt');
% data_info = textscan(fid,'%s');
% fclose(fid);
% 
% outputfilename=cell2mat(data_info{1,1}(1));
% logletoutput_filename=[outputfilename,'.xlsx'];
% country=cell2mat(data_info{1,1}(2));
% date=data_info{1,1}(4:end);
% 
% [numdata,~,fulldata] =xlsread(logletoutput_filename);
% rec_range=isfinite(numdata(:,1));
% fit_range=isfinite(numdata(:,5));
% t=numdata(rec_range,1);
% cumI=numdata(rec_range,2);
% tfit=numdata(fit_range,5);
% cumIfit=numdata(fit_range,6);
% 
% %% Find the final date of extrapolation
% dat0vec=datevec(date{1},'yyyy-mm-dd');
% days=datenum(dat0vec);
% daysshift=addtodate(days,tfit(end)-1,'day');
% datvecshift=datevec(daysshift);
% datefitends=datestr(datvecshift,'yyyy-mm-dd');
% Tend=tfit(end);
% Tdatefitends=datefitends;
% %% Analysis of the number of phases and existence of statistics
% 
% param1=numdata(isfinite(numdata(:,9)),9);
% num_phases=length(param1)/4;
% isstat=isfinite(numdata(1,11));
% num_intvl=~strcmp(fulldata(1,:),'');
% dnum_intvl=[0,diff(num_intvl)];
% ndnum_intvl=find(dnum_intvl==1);
% 
% for j=1:num_phases
%     col_bell=ndnum_intvl(3+2*(j-1));
%     col_t=ndnum_intvl(4+2*(j-1));
%     bell_rec_range{j}=isfinite(numdata(:,col_bell));
%     tfit_range{j}=isfinite(numdata(:,col_t));
%     tbell{j}=numdata(bell_rec_range{j}(2:end-1),col_bell);
%     bell{j}=numdata(bell_rec_range{j}(2:end-1),col_bell+5);
%     tbellfit{j}=numdata(tfit_range{j}(2:end-1),col_t);
%     bellfit{j}=numdata(tfit_range{j}(2:end-1),col_t+4);
%     
%     tphase_rec{j}=numdata(bell_rec_range{j},col_bell);
%     phase_rec{j}=numdata(bell_rec_range{j},col_bell+1);
%     phase_FP_rec{j}=numdata(bell_rec_range{j},col_bell+4);
% 
%     tphase_fit{j}=numdata(tfit_range{j},col_t);
%     phase_fit{j}=numdata(tfit_range{j},col_t+1);
%     if isstat
%         phase_stat{j}=numdata(tfit_range{j},col_t+5:col_t+7);
%     end
%     phase_FP_fit{j}=numdata(tfit_range{j},col_t+3);
% end
% 
% Tend=round(tphase_fit{num_phases}(end));
% Tdaysshift=addtodate(days,Tend-1,'day');
% Tdatvecshift=datevec(Tdaysshift);
% Tdatefitends=datestr(Tdatvecshift,'yyyy-mm-dd');
% 
% %%
% scumIfit=spline(tfit,cumIfit,t);
% indb1=find(cumI>max(cumI)*0.05);
% AAD=100*mean(abs(cumI(indb1(1):end)-scumIfit(indb1(1):end))./cumI(indb1(1):end))
% 
% 
% %% Composite plot
% figure(2)
% plot(t,cumI,'o','color','black','LineWidth',1.5);
% hold on
% plot(tfit(tfit>t(end)),cumIfit(tfit>t(end)),'--','color','red','LineWidth',1.5);
% plot(tfit(tfit<=t(end)),cumIfit(tfit<=t(end)),'-','color','red','LineWidth',1.5);
% grid on
% ylim([0 inf])
% ylabel('Total cases')
% title([country,': composite plot'])
% set(gca,'XTick',[t(1):60:t(end)],'XTickLabel',[date(1:60:end)],'FontSize',FS)
% set(gcf,'PaperUnits','inches','PaperPosition',[0 0 10 6],'PaperSize',[10 6])
% 
% 
% %% Bell plots
% figure(3)
% subplot(2,1,1)
% plot(Tout(1:121,1)',ICA(1:121),'-','LineWidth',1.5);
% hold on
% plot(Tout(1:121,1)',IMA(1:121),'LineWidth',1.5);
% l1=legend({'Catalonia','Madrid'});
% set(l1,'FontSize',FS)
% grid on
% xlim([0 121])
% ylim([0 250])
% ylabel('Cases per day')
% title('Recorded data for two regions')
% %set(gca,'XTick',[t(32):35:t(140)],'XTickLabel',[date(32:35:140)],'FontSize',FS)
% set(gca,'XTick',[t(1):60:t(end)],'XTickLabel',[date(1:60:end)],'FontSize',FS)
% 
% subplot(2,1,2)
% for j=1:num_phases
%     p{j}=plot(tbell{j},bell{j},'o','LineWidth',1.5);
%     clr{j}=get(p{j},'color');  
%     hold on
%     plot(tbellfit{j}(tbellfit{j}>tbell{j}(end)),bellfit{j}(tbellfit{j}>tbell{j}(end)),'--','color',clr{j},'LineWidth',1.5);
%     plot(tbellfit{j}(tbellfit{j}<=tbell{j}(end)),bellfit{j}(tbellfit{j}<=tbell{j}(end)),'-','color',clr{j},'LineWidth',1.5);
% end
% grid on
% xlim([0 121])
% ylim([0 250])
% ylabel('Rate (cases per day)')
% title('Two-phase decomposition')
% set(gca,'XTick',[t(1):60:t(end)],'XTickLabel',[date(1:60:end)],'FontSize',FS)
% set(gcf,'PaperUnits','inches','PaperPosition',[0 0 10 6],'PaperSize',[10 6])
% 
% %% Components plot
% 
% figure(4)
% subplot(2,1,1)
% plot(Tout(1:121,1)',cumsum(ICA(1:121)),'-','LineWidth',1.5)
% hold on
% plot(Tout(1:121,1)',cumsum(IMA(1:121)),'LineWidth',1.5)
% plot(Tout(1:121,1)',cumsum(IMA(1:121)+ICA(1:121)),'o-','color','black','LineWidth',1.5)
% grid on
% ylim([0 6000])
% xlim([0 121])
% ylabel('\Sigma I')
% title('Cumulative recorded data')
% set(gca,'XTick',[t(1):60:t(end)],'XTickLabel',[date(1:60:end)],'FontSize',FS)
% l1=legend({'Catalonia','Madrid','Both regions'});
% set(l1,'Location','northwest')
% 
% subplot(2,1,2)
% plot(t,cumI,'o','color','black','LineWidth',1.5);
% hold on
% plot(tfit(tfit>t(end)),cumIfit(tfit>t(end)),'--','color','red','LineWidth',1.5);
% plot(tfit(tfit<=t(end)),cumIfit(tfit<=t(end)),'-','color','red','LineWidth',1.5);
% 
% for j=1:num_phases
% plot(tphase_rec{j},phase_rec{j},'o','color',clr{j},'LineWidth',1.5);
% hold on
% plot(tphase_fit{j}(tphase_fit{j}>tphase_rec{j}(end)),phase_fit{j}(tphase_fit{j}>tphase_rec{j}(end)),'--','color',clr{j},'LineWidth',1.5);
% plot(tphase_fit{j}(tphase_fit{j}<=tphase_rec{j}(end)),phase_fit{j}(tphase_fit{j}<=tphase_rec{j}(end)),'-','color',clr{j},'LineWidth',1.5);
% if isstat
%     plot(tphase_fit{j},phase_stat{j}(:,1),':','color',clr{j},'LineWidth',1.5);
%     plot(tphase_fit{j},phase_stat{j}(:,2),':','color',clr{j},'LineWidth',1.5);
%     plot(tphase_fit{j},phase_stat{j}(:,3),'-.','color',clr{j},'LineWidth',1.5);
% end
% end
% grid on
% ylim([0 6000])
% xlim([0 121])
% ylabel('\Sigma I')
% title('Cumulative curve and its decomposition')
% set(gca,'XTick',[t(1):60:t(end)],'XTickLabel',[date(1:60:end)],'FontSize',FS)
% set(gcf,'PaperUnits','inches','PaperPosition',[0 0 10 6],'PaperSize',[10 6])
% 
%  
% %% Fisher-Pry components plot
% 
% figure(5)
% for j=1:num_phases
%     plot(tphase_rec{j},phase_FP_rec{j},'o','color',clr{j},'LineWidth',1.5);
%     hold on
%     plot(tphase_fit{j}(tphase_fit{j}>tphase_rec{j}(end)),phase_FP_fit{j}(tphase_fit{j}>tphase_rec{j}(end)),'--','color',clr{j},'LineWidth',1.5);
%     plot(tphase_fit{j}(tphase_fit{j}<=tphase_rec{j}(end)),phase_FP_fit{j}(tphase_fit{j}<=tphase_rec{j}(end)),'-','color',clr{j},'LineWidth',1.5);
% end
% grid on
% ylim([-2 2])
% ylabel('%')
% title([country,': Fisher-Pry plots'])
% set(gca,'XTick',[t(1):60:t(end)],'XTickLabel',[date(1:60:end)],'YTick',[-2 -1 0 1 2],'YTickLabel',[1 10 50 90 99],'FontSize',FS)
% set(gcf,'PaperUnits','inches','PaperPosition',[0 0 10 6],'PaperSize',[10 6])
% 
% 
% %% Printing figures
% if printfigures==1
% 
% % figure(1)
% %     print('Composite_plot',frmt,['-r',num2str(res)])    
% % figure(2)
% %     print('Bells_plot',frmt,['-r',num2str(res)])
% figure(3)
%     print('regESI',frmt,['-r',num2str(res)])
% figure(4)
%     print('regESR',frmt,['-r',num2str(res)])
% end
