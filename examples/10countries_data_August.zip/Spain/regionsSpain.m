clear;close all;clc;
FS=20;%Font size for figures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Printing options
printfigures=1;% 1 - "print"; 0 - "do not print";
frmt='-dpdf';
res=300;%resolution in dpi
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load Spain

[lent,cols]=size(datosprovincias);
P=52;%numbr of provinces
days=lent/P;

for j=1:days;
    I(j)=sum(cell2mat(datosprovincias(52*(j-1)+1:52*j,3)));
end

ind = strfind(datosprovincias(:,1),'CA');
ind=find(~cellfun(@isempty,ind));

ICA=cell2mat(datosprovincias(ind,3));

ind = strfind(datosprovincias(:,1),'MA');
ind=find(~cellfun(@isempty,ind));

IMA=cell2mat(datosprovincias(ind,3));

date=datosprovincias(1:52:end,2);
t=0:days-1;

subplot(2,1,1)
plot(t,ICA,'-','LineWidth',1.5);
hold on
plot(t,IMA,'LineWidth',1.5);
l1=legend({'Catalonia','Madrid'});
set(l1,'FontSize',FS)
xlim([0 121])
ylabel('Cases per day')
set(gca,'XTick',[t(32):35:t(140)],'XTickLabel',[date(32:35:140)],'FontSize',FS)
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 10 6],'PaperSize',[10 6])

subplot(2,1,2)
plot(cumsum(ICA),'-','LineWidth',1.5)
hold on
plot(cumsum(IMA),'LineWidth',1.5)
l1=legend({'Catalonia','Madrid'});
set(l1,'FontSize',FS)
xlim([0 121])
ylabel('Cumulative number')
set(gca,'XTick',[t(32):35:t(140)],'XTickLabel',[date(32:35:140)],'FontSize',FS)
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 10 6],'PaperSize',[10 6])

print('regES',frmt,['-r',num2str(res)]) 