clear;close all;clc;
FS=20;%Font size for figures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Printing options
printfigures=1;% 1 - "print"; 0 - "do not print";
frmt='-dpdf';
res=300;%resolution in dpi
%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[~,~,TBL]=xlsread('YandexData.xlsx');
[m,n]=size(TBL);
Date=TBL(2:end,1);
date=char(Date);
data=cell2mat(TBL(2:end,2:end-1));
for j=1:m-1;
    ind=isnan(data(j,:));
    data(j,ind)=0;
end
Data=sum(data);
is{1}=43-1;% Moscow
is{2}=[5,11,17,18,26,40,55,62,63,78,84,... % Far East
       3,4,21,29,34,49,50,74,74,79,... % Ural
       36,64,75,80,81,85]-1;% Siberia
   

days=0:m-2;
plot(days,data(:,is{1}),'color','red','LineWidth',1.5)
hold on
d5=sum(data(:,is{2})');
plot(days,d5,'color','green','LineWidth',1.5)
drest=sum(data(:,1:end)')-data(:,is{1})'-d5;
plot(days,drest,'color','blue','LineWidth',1.5)
set(gca,'XTick',[days(1):45:days(end)],'XTickLabel',[date(1:45:end,1:10)],'FontSize',FS)
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 10 6],'PaperSize',[10 6])
%grid on
legend(gca,{'Moscow','Asian part + Ural','European part - Moscow'},'Location','NorthEast')
ylabel('Cases per day')


print('regRu',frmt,['-r',num2str(res)]) 

